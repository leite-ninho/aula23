import React from 'react';

const menuItems = [
  {
    category: 'Cafés Especiais',
    items: [
      { name: 'Espresso', price: 'R$ 6,00', description: 'Café puro e intenso' },
      { name: 'Cappuccino', price: 'R$ 8,50', description: 'Café com leite vaporizado e chocolate' },
      { name: 'Latte', price: 'R$ 8,00', description: 'Café com leite cremoso' },
    ],
  },
  {
    category: 'Doces',
    items: [
      { name: 'Bolo de Cenoura', price: 'R$ 12,00', description: 'Com cobertura de chocolate' },
      { name: 'Brownie', price: 'R$ 10,00', description: 'Chocolate meio amargo' },
      { name: 'Croissant', price: 'R$ 8,00', description: 'Massa folhada tradicional' },
    ],
  },
];

export function Menu() {
  return (
    <section id="menu" className="py-16 bg-amber-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12 text-amber-900">Nosso Cardápio</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {menuItems.map((section) => (
            <div key={section.category} className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-2xl font-semibold mb-6 text-amber-800">{section.category}</h3>
              <div className="space-y-4">
                {section.items.map((item) => (
                  <div key={item.name} className="border-b border-amber-100 pb-4">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="text-lg font-medium">{item.name}</h4>
                      <span className="text-amber-700 font-semibold">{item.price}</span>
                    </div>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}