import React from 'react';

export function About() {
  return (
    <section id="sobre" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1442512595331-e89e73853f31"
              alt="Interior da cafeteria"
              className="rounded-lg shadow-lg"
            />
          </div>
          <div>
            <h2 className="text-4xl font-bold mb-6 text-amber-900">Nossa História</h2>
            <p className="text-gray-700 mb-4">
              Desde 2010, o Café Aroma tem sido mais do que uma simples cafeteria. Somos um espaço
              onde histórias são compartilhadas, amizades são fortalecidas e momentos especiais são
              criados.
            </p>
            <p className="text-gray-700 mb-4">
              Nossa paixão pelo café nos leva a buscar constantemente os melhores grãos e métodos
              de preparo, garantindo uma experiência única em cada xícara.
            </p>
            <p className="text-gray-700">
              Venha nos conhecer e fazer parte desta história!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}