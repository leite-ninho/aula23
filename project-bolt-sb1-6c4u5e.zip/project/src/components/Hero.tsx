import React from 'react';

export function Hero() {
  return (
    <section className="relative h-[600px]">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085"
          alt="Café sendo preparado"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
      </div>
      <div className="relative container mx-auto px-4 h-full flex items-center">
        <div className="max-w-2xl text-white">
          <h2 className="text-5xl font-bold mb-4">Descubra o verdadeiro sabor do café</h2>
          <p className="text-xl mb-8">Grãos selecionados, ambiente acolhedor e experiências únicas</p>
          <button className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors">
            Ver Cardápio
          </button>
        </div>
      </div>
    </section>
  );
}