import React from 'react';
import { Coffee, Menu } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-amber-900 text-amber-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Coffee className="h-8 w-8" />
          <h1 className="text-2xl font-bold">Café Aroma</h1>
        </div>
        <nav className="hidden md:flex items-center gap-6">
          <a href="#inicio" className="hover:text-amber-200 transition-colors">Início</a>
          <a href="#menu" className="hover:text-amber-200 transition-colors">Cardápio</a>
          <a href="#sobre" className="hover:text-amber-200 transition-colors">Sobre</a>
          <a href="#contato" className="hover:text-amber-200 transition-colors">Contato</a>
        </nav>
        <button className="md:hidden">
          <Menu className="h-6 w-6" />
        </button>
      </div>
    </header>
  );
}